
# PolarFire SoC MSS Ethernet MAC Test program - Single MAC, Single Queue 


Tested for Polarfire Discovery  Kit with VSC8221 PHY

